import { Injectable } from '@angular/core';
import { Livro } from './livro.model'
import { Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map, timestamp } from 'rxjs/operators';
import { Router } from '@angular/router';


@Injectable ({providedIn: 'root'})
export class LivroService {
  private livros: Livro[] = [];
  private listaLivrosAtualizada = new Subject <Livro[]>();

  constructor (
    private httpClient: HttpClient,
    private router: Router
  ){

  }

  getLivro (idLivro: string){
    return this.httpClient.get<{_id: string, isbn: string, titulo: string, autor: string, paginas: string}>(
      `http://localhost:3000/api/livros/${idLivro}`
    )
  }

  getLivros(): void{
    this.httpClient.get<{mensagem: string, livros: any}>('http://localhost:3000/api/livros').
    pipe(map((dados => {
      return dados.livros.map((livro) => {
        return {
          id: livro._id,
          isbn: livro.isbn,
          titulo: livro.titulo,
          autor: livro.autor,
          paginas: livro.paginas
        }
      });
    }))).
    subscribe((livros) => {
      this.livros = livros;
      this.listaLivrosAtualizada.next([...this.livros]);//push
    })
  }

  atualizarLivro (isbn: string, titulo: string, autor: string, paginas: string){
    const livro: Livro = {isbn, titulo, autor, paginas};
    this.httpClient.put(`http://localhost:3000/api/livros/${isbn}`, livro)
    .subscribe(res => {
      const copia = [...this.livros];
      const indice = copia.findIndex (cli => cli.isbn === livro.isbn);
      copia[indice] = livro;
      this.livros = copia;
      this.listaLivrosAtualizada.next([...this.livros]);
      this.router.navigate(['/']);
    });
  }

  adicionarLivro (isbn: string, titulo: string, autor: string, paginas: string): void{
    const livro: Livro = {
      isbn: null,
      titulo: titulo,
      autor: autor,
      paginas: paginas
    };
    this.httpClient.post <{mensagem: string, id:string}> ('http://localhost:3000/api/livros', livro).subscribe((resposta) =>{
      console.log (resposta.mensagem);
      livro.isbn = resposta.id;
      this.livros.push(livro);
      this.listaLivrosAtualizada.next([...this.livros]);
      this.router.navigate(['/'])
    })
  }

  removerLivro (id: string): void{
    this.httpClient.delete(`http://localhost:3000/api/livros/${id}`)
    .subscribe(() => {
      this.livros = this.livros.filter((cli) => {
        return cli.isbn !== id
      })
      this.listaLivrosAtualizada.next([...this.livros]);
    })
  }

  getListaLivrosAtualizada () {
    return this.listaLivrosAtualizada.asObservable();
  }
}
