export interface Livro {
  isbn: string;
  titulo: string;
  autor: string;
  paginas: string;
}
